# WiFi Portal Backend

Ce projet est un backend en Node.js pour un portail WiFi.

## 📌 Installation et Lancement

1. Installer les dépendances :
   ```sh
   npm install
   ```

2. Copier le fichier `.env.example` en `.env` et renseigner `MONGO_URI` avec votre base de données MongoDB.

3. Lancer le serveur :
   ```sh
   npm start
   ```

## 🚀 Hébergement sur Render

1. Créez un compte sur [Render](https://render.com/).
2. Ajoutez un nouveau Web Service.
3. Uploadez ce projet.
4. Configurez `MONGO_URI` dans les variables d'environnement.
5. Lancez le déploiement.

---
Développé pour une intégration facile. Contactez-moi si besoin !
